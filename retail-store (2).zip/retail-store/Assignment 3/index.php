<?php include 'db.php'; ?>
<h1>Retail Store Management System</h1>
<ul>
    <li><a href='add_item.php'>Add Item</a></li>
    <li><a href='update_item.php'>Update Item</a></li>
    <li><a href='delete_item.php'>Delete Item</a></li>
    <li><a href='record_sale.php'>Record Sale</a></li>
    <li><a href='record_return.php'>Record Return</a></li>
    <li><a href='report.php'>View Report</a></li>
</ul>